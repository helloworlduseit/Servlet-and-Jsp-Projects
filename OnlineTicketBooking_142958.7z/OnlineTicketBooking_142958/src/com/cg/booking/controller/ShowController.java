package com.cg.booking.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.booking.dto.ShowDetails;
import com.cg.booking.exception.BookingException;
import com.cg.booking.service.ShowService;
import com.cg.booking.service.ShowServiceImpl;

@WebServlet(urlPatterns={"/showdetail","/Book","/hello"})
public class ShowController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
 
    public ShowController() 
    {
        super();
      
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl = "";
		ShowService showSer = new ShowServiceImpl();
		switch(url)
		{
		case "/showdetail":
		{
			HttpSession sess=request.getSession(true);
			try
			{
				List<ShowDetails> Show=showSer.getAllShowDetails();
				sess.setAttribute("show", Show);
				targetUrl="showDetails.jsp";
			}
			catch(BookingException e)
			{
				sess.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		}
		case "/Book":
		{
			String name= request.getParameter("showName");
			String id= request.getParameter("showId");
			String price= request.getParameter("price");
			String seatAvail= request.getParameter("avail");
			HttpSession sess=request.getSession(true);
			sess.setAttribute("name", name);
			sess.setAttribute("id", id);
			sess.setAttribute("price", price);
			sess.setAttribute("seatAvail", seatAvail);
			targetUrl="bookNow.jsp";
			break;
		}
		case "/hello":
		{		
			HttpSession sess=request.getSession(false);
			String showId=(String) sess.getAttribute("id");
			sess.setAttribute("ShowName", (String)request.getParameter("txtShowName"));
			sess.setAttribute("CustName", (String)request.getParameter("txtCustName"));
			sess.setAttribute("mobile",(String) request.getParameter("mobileno"));
			sess.setAttribute("noOfSeats", (String)request.getParameter("noOfSeats"));
			float noOfSeats=Float.parseFloat(request.getParameter("noOfSeats"));
			float pricePerSeat=Float.parseFloat(request.getParameter("txtPrice"));
			int data;
			try {
				data = showSer.UpdateShowDetails(showId, noOfSeats);
				if (data==1)
				{
				float totalPrice=noOfSeats*pricePerSeat;
				sess.setAttribute("totalPrice",totalPrice );
				targetUrl="Success.jsp";
				}
				else
				{
					sess.setAttribute("error", "Problem while execution of Update Query");
					targetUrl="Error.jsp";
				}
			} 
			catch (BookingException e) {
				
				sess.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
		}
		}
		RequestDispatcher disp=
				request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
		
	}

}
