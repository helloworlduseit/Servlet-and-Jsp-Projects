/*Dao Implementaion class which consist implementation of Dao **/
package com.cg.booking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.booking.DBUtil.DBUtil;
import com.cg.booking.dto.ShowDetails;
import com.cg.booking.exception.BookingException;

/****************Display all showdetails table from database**********************/
public class ShowDaoImpl implements ShowDao {
	Connection conn;
	@Override
	public List<ShowDetails> getAllShowDetails() throws BookingException {
		conn=DBUtil.getConnection();
		List<ShowDetails> ListShow=new ArrayList<>();
		Statement st;
		try 
		{
			st = conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_BOOKDETAILS);
			while(rst.next())
			{
				ShowDetails show=new ShowDetails();
				show.setShowId(rst.getString("ShowId"));
				show.setShowName(rst.getString("ShowName"));
				show.setLocation(rst.getString("Location"));
				show.setDate(rst.getDate("ShowDate").toLocalDate());
				show.setAvailTicket(rst.getInt("AvSeats"));
				show.setPriceTicket(rst.getInt("PriceTicket"));
				ListShow.add(show);
			}
		} 
		catch (SQLException e) 
		{
			throw new BookingException("Problem in Fetching showDetails table from Database");
		}
		
		return ListShow;
	}
/*************************Update showdetails table*****************************/
	@Override
	public int UpdateShowDetails(String showId,float noOfSeats)
			throws BookingException
	{
		conn=DBUtil.getConnection();
		PreparedStatement pst;
		int data = 0;
		try 
		{
			pst = conn.prepareStatement(QueryMapper.UPDATE_BOOKDETAILS);
			pst.setFloat(1, noOfSeats);
			pst.setString(2, showId);
			data=pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();	
			throw new BookingException("Problem while Updating showDetails table in Database");
		}
		
		return data;
	}

}
