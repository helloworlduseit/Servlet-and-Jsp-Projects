/**
 * 
 */
package com.cg.booking.service;

import java.util.List;

import com.cg.booking.dao.ShowDao;
import com.cg.booking.dao.ShowDaoImpl;
import com.cg.booking.dto.ShowDetails;
import com.cg.booking.exception.BookingException;

/**
 * @author jymane
 *
 */
public class ShowServiceImpl implements ShowService {
	ShowDao sDao= new ShowDaoImpl();

	@Override
	public List<ShowDetails> getAllShowDetails() throws BookingException 
	{
		return sDao.getAllShowDetails();
	}

	
	@Override
	public int UpdateShowDetails(String showId,float noOfSeats)
			throws BookingException 
	{		
		return sDao.UpdateShowDetails(showId, noOfSeats);
	}

}
