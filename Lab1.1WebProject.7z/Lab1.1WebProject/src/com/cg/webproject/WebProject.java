package com.cg.webproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "WebProjectName", urlPatterns = { "/WebProjectMap" })
public class WebProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public WebProject() {
        super();
  
    }

	
	public void init(ServletConfig config) throws ServletException {

	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("System Date and Time is : "+LocalDateTime.now());

	}

}
