package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UrlReWriteServet")
public class UrlReWriteServet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	int count;
	ServletConfig cg;
    public UrlReWriteServet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
	}

	
	public void destroy() {
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String id=request.getParameter("id");
		if(id==null)
		{
			id="1";
			count=Integer.parseInt(id);
			count++;
			
		}
		else
		{
			count=Integer.parseInt(id);
			count++;
		}
		PrintWriter pw=response.getWriter();
		pw.println("<b>I was Visited : "+count+" times.</b>");
		pw.println("<br/>Do You want to visit me Again ?");
		pw.println("<a href='/SessionProject/UrlReWriteServet?id="+count+"'>Click Here"
				+ " To Visit again</a>");
		
	}

}
