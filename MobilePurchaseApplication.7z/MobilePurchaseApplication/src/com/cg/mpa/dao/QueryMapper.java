package com.cg.mpa.dao;

public interface QueryMapper {

	
		String SELECT_ALL_MOBILES = "SELECT mobileid,name,price,quantity FROM MOBILES";
		
		String SELECT_MOBILE="SELECT mobileid,name,price,quantity FROM MOBILES WHERE mobileid=?";
		String SELECT_SEQUENCE="SELECT purchase_seq.NEXTVAL FROM DUAL";
		String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?, ?, ?, ?, ?, ?)";
	

}
