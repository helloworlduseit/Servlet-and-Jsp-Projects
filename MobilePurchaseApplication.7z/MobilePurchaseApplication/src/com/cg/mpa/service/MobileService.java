package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface MobileService 
{
	List<Mobiles> getAllMobiles() throws MobileException;
	Mobiles getMobile(long mid) throws MobileException;
	long insertPurchaseDetails(PurchaseDetails pDetails) throws MobileException;

}
