package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements MobileService 
{
	MobilePurchaseDao mDao=new MobilePurchaseDaoImpl();
	

	@Override
	public List<Mobiles> getAllMobiles() throws MobileException
	{
		return mDao.getAllMobiles();
	}

	@Override
	public Mobiles getMobile(long mid) throws MobileException 
	{
		return mDao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException 
	{
		return mDao.insertPurchaseDetails(pDetails);
	}

}
