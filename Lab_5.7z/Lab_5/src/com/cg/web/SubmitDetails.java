package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Consumers;
import com.cg.exception.BillException;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;


@WebServlet("/SubmitDetails")
public class SubmitDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    ConsumerService consumerSer=null;
    public SubmitDetails() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		Consumers Consumer=new Consumers();
		consumerSer=new ConsumerServiceImpl();
		HttpSession session=request.getSession(true);
		RequestDispatcher rd;
		try 
		{
			PrintWriter pw=response.getWriter();
			//pw.print("SubmitDetails");
		
			String id=request.getParameter("txtNumber");
			long conNo=Long.parseLong(id);
			Consumer.setConsumerNum(conNo);
			String name= consumerSer.getDetails(Consumer);
			String currRead= request.getParameter("txtCurrent");
			String lastRead= request.getParameter("txtLast");
			session.setAttribute("DisplayObj1", name);
			session.setAttribute("DisplayObj2", id);
			session.setAttribute("DisplayObj3", currRead);
			session.setAttribute("DisplayObj4", lastRead);
			rd=request.getRequestDispatcher("SuccessPage");
			rd.forward(request, response);
			
		} 
		catch (BillException e) {
			request.setAttribute("ErrorMsgObj", e.getMessage());
			RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
			rdError.forward(request, response); 
			
		}
		
	}

}
