package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ConsumerService conSer=null;
	Consumers cu=new Consumers();
	BillDetails billDetail=null;   
  
    public SuccessPage() {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
	
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		conSer = new ConsumerServiceImpl();
		billDetail=new BillDetails();
		try 
		{
		HttpSession ses=request.getSession(true);
		String nm=(String) ses.getAttribute("DisplayObj1");
		String id=(String) ses.getAttribute("DisplayObj2");
		String currRead=(String) ses.getAttribute("DisplayObj3");
		String lastRead=(String) ses.getAttribute("DisplayObj4");
		long conId=Long.parseLong(id);
		double current=Double.parseDouble(currRead);
		double last=Double.parseDouble(lastRead);
		if(current<=last)
		{
			double unitConsumed=last-current;
			double fixedChardge=100;
			double netAmount=unitConsumed*1.15 +fixedChardge;
			
			cu.setConsumerNum(conId);
			billDetail.setCurrReading(current);
			billDetail.setUnitConsumed(unitConsumed);
			billDetail.setNetAmount(netAmount);
			
			int data=conSer.setBillDetails(billDetail,cu);
		
			out.print("<h4>Welcome "+nm+"</h4>");
			out.print("<h1>Electricity Bill for Consumer Number - "+id+" is <h1>");
			out.print("<h2>Unit Consumed :: "+unitConsumed+"</h2>");
			out.print("<h2>Net Amount :: Rs."+netAmount+"</h2>");
		}
		else
		{
			String msg = "Current Month meter reading is greator than Last Month meter reading";
		request.setAttribute("ErrorMsgObj", msg);
		RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
		rdError.forward(request, response); 

			
			throw new BillException
			("Current Month meter reading cannot be greater than Last Month meter reading");
		}
		
		
		
	}
		catch (BillException e) 
		{
			
			e.printStackTrace();
		}
	}

}
