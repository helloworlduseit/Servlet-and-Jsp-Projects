package com.cg.service;

import java.util.function.Consumer;

import com.cg.dao.ConsumerDao;
import com.cg.dao.ConsumerDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;

public class ConsumerServiceImpl implements ConsumerService {

	ConsumerDao condao=null;
	public ConsumerServiceImpl()
	{
		condao=new ConsumerDaoImpl();
	}
	@Override
	public String getDetails(Consumers Consumer) throws BillException {
		
		return condao.getDetails(Consumer);
	}
	@Override
	public int setBillDetails(BillDetails billDet,Consumers con) throws BillException {
		
		return condao.setBillDetails(billDet,con);
	}
	

}
