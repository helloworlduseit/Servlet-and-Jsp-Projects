package com.cg.service;

import java.util.function.Consumer;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;

public interface ConsumerService {
	public String getDetails(Consumers Consumer) throws BillException ;
	public int setBillDetails(BillDetails billDet,Consumers con) throws BillException;
}
