package com.cg.dto;

public class Consumers 
{
	private long consumerNum;
	private String consumerName;
	private String consumerAdd;
	public Consumers() {
		super();
		
	}
	public Consumers(long consumerNum, String consumerName, String consumerAdd) {
		super();
		this.consumerNum = consumerNum;
		this.consumerName = consumerName;
		this.consumerAdd = consumerAdd;
	}
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAdd() {
		return consumerAdd;
	}
	public void setConsumerAdd(String consumerAdd) {
		this.consumerAdd = consumerAdd;
	}
	@Override
	public String toString() {
		return "Consumers [consumerNum=" + consumerNum + ", consumerName="
				+ consumerName + ", consumerAdd=" + consumerAdd + "]";
	}
	
	
	

}
