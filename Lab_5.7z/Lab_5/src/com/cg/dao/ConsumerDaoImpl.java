package com.cg.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.dto.Login;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;

public class ConsumerDaoImpl implements ConsumerDao
{
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Statement st=null;

	@Override
	public String getDetails(Consumers Consumer) throws BillException 
	{
		String conName;
		try
		{
		conn=DBUtil.getcon();
		//System.out.println("Got Connection");
		String qry="SELECT * FROM Consumers WHERE consumer_num=?";
		pst=conn.prepareStatement(qry);
	//	System.out.println(Consumer.getConsumerNum());
		pst.setLong(1, Consumer.getConsumerNum());
		rs=pst.executeQuery();
		rs.next();
		conName=rs.getString("consumer_name");
		//System.out.println(conName);
		}
		catch(Exception e)
		{
			throw new BillException("Entered Consumer number does not exist!!");
		}
		finally
		{
			try
			{
			conn.close();
			pst.close();
			rs.close();
			}
			catch(Exception e)
			{
				throw new BillException(e.getMessage());
			}
		}
		return conName;

	}

	@Override
	public int setBillDetails(BillDetails billDet,Consumers con) throws BillException {
		
		int dataAdded;
		String insertQry="INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(?, ?, ?, ?, ?, sysdate)";
		try 
		{
			conn=DBUtil.getcon();
			pst=conn.prepareStatement(insertQry);
			pst.setLong(1, getBillNo());
			pst.setLong(2, con.getConsumerNum());
			pst.setDouble(3, billDet.getCurrReading());
			pst.setDouble(4, billDet.getUnitConsumed());
			pst.setDouble(5, billDet.getNetAmount());
			dataAdded=pst.executeUpdate();
					} 
		catch (Exception e) 
		{
			//mobLogger.error("This is Exception:"+e.getMessage());
			throw new BillException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BillException(e.getMessage());	
			}
		}
		return dataAdded;
	}
	public long getBillNo() throws BillException
	{
		int generatedVal;
		String qry="SELECT seq_bill_num.NEXTVAL "
				+ " FROM DUAL";
		try 
		{
			conn=DBUtil.getcon();;
			st=conn.createStatement();
			rs=st.executeQuery(qry);

			rs.next();

			generatedVal=rs.getInt(1);

		} 
		catch (Exception e) 
		{

			throw new BillException(e.getMessage());		
		} 
		finally//reqd to closing all connections which are opened like con
		{
			try 
			{
				rs.close();
				conn.close();
				st.close();
			} 
			catch (SQLException e) 
			{	
				throw new BillException(e.getMessage());		
			}

		}
		return generatedVal;
	}
	/**************************************************************************/


}
