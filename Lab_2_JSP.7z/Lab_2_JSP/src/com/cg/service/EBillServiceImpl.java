package com.cg.service;

import java.util.List;

import com.cg.dao.EBillDao;
import com.cg.dao.EBillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;

public class EBillServiceImpl implements EBillService {
	EBillDao eBill = new EBillDaoImpl();
	@Override
	public List<Consumers> getAllConsumers() throws EBillException {
		return eBill.getAllConsumers();
	}

	@Override
	public Consumers getConsumer(long consumerNo) throws EBillException {
		return eBill.getConsumer(consumerNo);
	}

	@Override
	public long insertBillDetails(BillDetails bDetails) throws EBillException {
		return eBill.insertBillDetails(bDetails);
	}

	@Override
	public List<BillDetails> getBillDetails(long consumerNo)
			throws EBillException {
		return eBill.getBillDetails(consumerNo);
	}

}
