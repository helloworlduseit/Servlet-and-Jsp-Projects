package com.cg.service;

import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;

public interface EBillService
{
	List<Consumers> getAllConsumers() throws EBillException;
	Consumers getConsumer(long consumerNo) throws EBillException;
	long insertBillDetails(BillDetails bDetails) throws EBillException;
	public List<BillDetails> getBillDetails(long consumerNo) throws EBillException;
}
