package com.cg.dto;

import java.time.LocalDate;

public class BillDetails 
{
	private long billNo;
	private long consumerNo;
	private double currReading;
	private double unitConsumed;
	private double netAmount;
	private LocalDate billDate;
	public BillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BillDetails(long billNo, long consumerNo, double currReading,
			double unitConsumed, double netAmount, LocalDate billDate) {
		super();
		this.billNo = billNo;
		this.consumerNo = consumerNo;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public long getBillNo() {
		return billNo;
	}
	public void setBillNo(long billNo) {
		this.billNo = billNo;
	}
	public long getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(long consumerNo) {
		this.consumerNo = consumerNo;
	}
	public double getCurrReading() {
		return currReading;
	}
	public void setCurrReading(double currReading) {
		this.currReading = currReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}
		
}
