package com.cg.user.service;

import java.sql.SQLException;



import com.cg.user.exception.LoginException;
import com.cg.user.dto.Login;

public interface LoginService
{
	public Login getUserByUnm(String unm) throws LoginException;

}
