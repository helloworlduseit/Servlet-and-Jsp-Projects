package com.cg.user.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.user.dto.Login;
import com.cg.user.service.LoginService;
import com.cg.user.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ServletConfig cg=null;
	LoginService logSer=null;
	public LoginController() {
		super();

	}


	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}


	public void destroy() {

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		logSer= new LoginServiceImpl();
		String action=request.getParameter("action");
		RequestDispatcher rd;
		HttpSession session=request.getSession(true);
		if(action!=null)
		{
			/*******************ShowWelcomePage********************/
			try
			{
				if(action.equals("ShowWelcomePage"))
				{
					rd=request.getRequestDispatcher("Pages/Welcome.jsp");
					rd.forward(request, response);
				}

				/*******************End ShowWelcomePage********************/

				/***********showLoginPage***********************/
				if(action.equals("ShowLoginPage"))
				{
					rd=request.getRequestDispatcher("Pages/Login.jsp");
					rd.forward(request, response);

				}
				/****************End showLoginPage*********************************/
				/*******************ShowSuccessPage******************/
				if(action.equals("ShowSuccessPage"))
				{
					
					String unm=request.getParameter("txtName");
					String pwd=request.getParameter("txtPwd");
					Login user=logSer.getUserByUnm(unm);
					if((user.getUserName().equalsIgnoreCase(unm)) &&
							(user.getPassword().equalsIgnoreCase(pwd)))
					{
						session.setAttribute("UserNameObj", unm);
						rd=request.getRequestDispatcher("SuccessPage");
						rd.forward(request, response);
					}
					else
					{
						String msg="Sorry!! Please check your Password";
						request.setAttribute("ErrorMsgObj", msg);
						rd=request.getRequestDispatcher("Pages/Login.jsp");
						rd.forward(request, response);
					}
				}
				/*******************End ShowSuccessPage******************/
			}

			catch(Exception ee)
			{
				String erMsg=ee.getMessage();
				request.setAttribute("ErrorMsgObj", erMsg);
				RequestDispatcher rdErro=request.getRequestDispatcher("ShowErrorPage");
				rdErro.forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("No Acion Defined...");
		}
	}

}
