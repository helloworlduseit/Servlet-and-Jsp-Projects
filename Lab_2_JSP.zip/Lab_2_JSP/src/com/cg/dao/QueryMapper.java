package com.cg.dao;

public interface QueryMapper 
{
	String SELECT_ALL_CONSUMERS="SELECT * FROM Consumers";
	String SELECT_CONSUMER="SELECT * FROM Consumers WHERE consumer_num=?";
	String INSERT_QUERY="INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(?, ?, ?, ?, ?, ?)";
	String SELECT_SEQUENCE="SELECT seq_bill_num.NEXTVAL FROM DUAL";
	String SELECT_BILL_DETAILS="SELECT * FROM BillDetails WHERE consumer_num=?";
}
