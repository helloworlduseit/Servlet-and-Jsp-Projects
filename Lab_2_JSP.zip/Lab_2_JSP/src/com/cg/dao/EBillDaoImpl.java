package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.DBUtil.DBUtil;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;

public class EBillDaoImpl implements EBillDao {
	Connection conn;
	@Override
	public List<Consumers> getAllConsumers() throws EBillException {
		conn=DBUtil.getConnection();
		List<Consumers> clist=new ArrayList<>();
		try{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_CONSUMERS);
			while(rst.next())
			{
				Consumers c=new Consumers();
				c.setConsumerNum(rst.getLong("consumer_num"));
				c.setConsumerName(rst.getString("consumer_name"));
				c.setConsumerAdd(rst.getString("address"));
				clist.add(c);
			}
			}
			catch(SQLException e)
			{
				throw new EBillException("Problem in Fetching Consumer list");
			}
		return clist;
	}
	
	/***************************************************************/
	private long generateBillId() throws EBillException
	{
		long bid=0;
		conn=DBUtil.getConnection();
		Statement st;
		try 
		{
		st = conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
		rst.next();
		bid=rst.getLong(1);
		}
		catch (SQLException e) 
		{
			throw new EBillException("Problem in Generating Bill Id "+e.getMessage());
		}
		return bid;
	}
	/*********************************************************************/

	@Override
	public Consumers getConsumer(long consumerNo) throws EBillException {
	
		conn=DBUtil.getConnection();
		Consumers c=null;
		try 
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_CONSUMER);
			pst.setLong(1, consumerNo);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				c=new Consumers();
				c.setConsumerNum(rst.getLong("consumer_num"));
				c.setConsumerName(rst.getString("consumer_name"));
				c.setConsumerAdd(rst.getString("address"));
			}
			else
			{
				throw new EBillException("Consumer Not Found");
			}
		} 
		catch (SQLException e) {
			throw new EBillException("Problem in Fetching Consumer details");
		}
		
		return c;
	}
/******************************************************************************/
	@Override
	public long insertBillDetails(BillDetails bDetails) throws EBillException {
		
		conn=DBUtil.getConnection();
		bDetails.setBillNo(generateBillId());
		try {
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, bDetails.getBillNo());
			pst.setLong(2, bDetails.getConsumerNo());
			pst.setDouble(3, bDetails.getCurrReading());
			pst.setDouble(4, bDetails.getUnitConsumed());
			pst.setDouble(5, bDetails.getNetAmount());
			pst.setDate(6, Date.valueOf(bDetails.getBillDate()));
			pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new EBillException("Problem in inserting BillDetails "+e.getMessage());
		}
		
		return bDetails.getBillNo();
	}

@Override
public List<BillDetails> getBillDetails(long consumerNo) throws EBillException {
	conn=DBUtil.getConnection();
	List<BillDetails> blist=new ArrayList<>();
	try{
		PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_BILL_DETAILS);
		pst.setLong(1, consumerNo);
		ResultSet rst=pst.executeQuery();
	
		while(rst.next())
		{
			BillDetails b=new BillDetails();
			b.setBillNo(rst.getLong("bill_num"));
			b.setConsumerNo(rst.getLong("consumer_num"));
			b.setCurrReading(rst.getDouble("cur_reading"));
			b.setUnitConsumed(rst.getDouble("unitConsumed"));
			b.setNetAmount(rst.getDouble("netAmount"));
			b.setBillDate(rst.getDate("bill_date").toLocalDate());
			blist.add(b);
		}
		}
		catch(SQLException e)
		{
			throw new EBillException("Problem in Fetching Bill details list from database");
		}
	return blist;
}

}
