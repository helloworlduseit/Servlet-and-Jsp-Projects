package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;

import com.cg.exception.EBillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;




@WebServlet(urlPatterns={"/list","/search","/billdetail","/home","/showconsumer","/userinput","/success"})
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public EBillController() {
		super();

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl = "";
		EBillService eSer=new EBillServiceImpl();
		switch(url)
		{
		case "/list":
		{
			HttpSession sess=request.getSession(true);
			try
			{
				
				List<Consumers> clist=eSer.getAllConsumers();
				sess.setAttribute("clist", clist);
				targetUrl="Show_ConsumerList.jsp";
			}
			catch(EBillException e)
			{
				sess.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		}
		case "/search":
		{
			targetUrl="Search_Consumer.jsp";
			break;
		}
		case "/billdetail":
		{
			HttpSession sess=request.getSession(false);
			long conNo=	Long.parseLong(request.getParameter("consumerNo"));
			//long conNo=(long) sess.getAttribute("consumerNo");
			try{
			List<BillDetails> blist=eSer.getBillDetails(conNo);
			sess.setAttribute("blist", blist);
			sess.setAttribute("consumerNo", conNo);
			targetUrl="Show_Bills.jsp";
			}
			catch(EBillException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		}
		case "/home":
		{
			targetUrl="index.html";
			break;
		}
		case "/showconsumer":
		{
			long consumerNo=Long.parseLong(request.getParameter("conNum"));
			try 
			{
				Consumers consumer=eSer.getConsumer(consumerNo);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("consumer", consumer);
		//		sess.setAttribute("consumerNo", consumer.getConsumerNum());
				targetUrl="Show_Consumer.jsp";
			} 
			catch (EBillException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
		}
		case "/userinput":
		{
			targetUrl="User_Info.jsp";
			break;
		}
		case "/success":
		{
			PrintWriter out=response.getWriter();
			String id=request.getParameter("txtNumber");
		//	Consumer.setConsumerNum(conNo);
			//String name= consumerSer.getDetails(Consumer);
			String currRead= request.getParameter("txtCurrent");
			String lastRead= request.getParameter("txtLast");
			long conId=Long.parseLong(id);
			double current=Double.parseDouble(currRead);
			double last=Double.parseDouble(lastRead);
			if(current<=last)
			{
				double unitConsumed=last-current;
				double fixedChardge=100;
				double netAmount=unitConsumed*1.15 +fixedChardge;
				
				
				//out.print("<h4>Welcome "+nm+"</h4>");
				out.print("<h1>Electricity Bill for Consumer Number - "+id+" is <h1>");
				out.print("<h2>Unit Consumed :: "+unitConsumed+"</h2>");
				out.print("<h2>Net Amount :: Rs."+netAmount+"</h2>");
			}
			else
			{
				String msg = "Current Month meter reading is greator than Last Month meter reading";
			request.setAttribute("ErrorMsgObj", msg);
			RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
			rdError.forward(request, response); 

				
				//throw new EBillException
			//	("Current Month meter reading cannot be greater than Last Month meter reading");
			}
			targetUrl="User_Info.jsp";
			break;
		}
		}
		RequestDispatcher disp=
				request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}
}
